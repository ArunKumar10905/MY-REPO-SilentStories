import express from 'express';
import cors from 'cors';
import session from 'express-session';
import bcrypt from 'bcryptjs';
import pg from 'pg';
import dotenv from 'dotenv';

dotenv.config();

const { Pool } = pg;
const app = express();
const PORT = 3001;

// Database connection
const pool = new Pool({
  connectionString: process.env.DATABASE_URL || 'postgresql://localhost/story_website',
});

// Initialize database
async function initDatabase() {
  const client = await pool.connect();
  try {
    await client.query(`
      CREATE TABLE IF NOT EXISTS admins (
        id SERIAL PRIMARY KEY,
        username VARCHAR(255) UNIQUE NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        last_login TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS stories (
        id SERIAL PRIMARY KEY,
        title VARCHAR(500) NOT NULL,
        content TEXT NOT NULL,
        category VARCHAR(100),
        tags TEXT,
        publish_date DATE NOT NULL,
        views INTEGER DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS comments (
        id SERIAL PRIMARY KEY,
        story_id INTEGER REFERENCES stories(id) ON DELETE CASCADE,
        visitor_name VARCHAR(255) NOT NULL,
        text TEXT,
        rating INTEGER CHECK (rating >= 1 AND rating <= 5),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS visitor_sessions (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        last_active TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    // Check if admin exists, if not create default admin
    const adminCheck = await client.query('SELECT * FROM admins WHERE username = $1', ['ArunKumar']);
    if (adminCheck.rows.length === 0) {
      const hashedPassword = await bcrypt.hash('10092005', 10);
      await client.query(
        'INSERT INTO admins (username, password_hash) VALUES ($1, $2)',
        ['ArunKumar', hashedPassword]
      );
      console.log('Default admin created: ArunKumar / 10092005');
    }

    // Create sample story if none exists
    const storyCheck = await client.query('SELECT COUNT(*) FROM stories');
    if (parseInt(storyCheck.rows[0].count) === 0) {
      await client.query(`
        INSERT INTO stories (title, content, category, tags, publish_date)
        VALUES (
          'Monthly Story — September',
          '<h2>The Coffee Shop at Dawn</h2><p>The first rays of sunlight filtered through the window of the small coffee shop on the corner of Fifth and Main. Sarah had been coming here every morning for the past three years, always ordering the same thing: a medium latte with an extra shot.</p><p>But today was different. Today, she noticed something she had never seen before...</p><p>The barista, whose name tag read "Michael," had been watching her with a curious expression. When their eyes met, he smiled and said something that would change everything.</p><p>"I''ve been wanting to tell you something for a long time," he began, his voice barely above a whisper. "Every morning, I make your coffee with a little extra care. Not because it''s my job, but because your smile when you take that first sip makes my entire day worthwhile."</p><p>Sarah felt her cheeks flush. In three years of routine, she had never truly seen him. But now, in this moment, everything was different.</p><p>"Would you like to stay for a while?" he asked, gesturing to a small table by the window. "I''d love to hear your story."</p><p>And so, over coffee and conversation, two strangers became something more. Sometimes, the most beautiful stories begin in the most ordinary places.</p>',
          'Real life',
          'romance, coffee, morning, connection',
          CURRENT_DATE
        )
      `);
      console.log('Sample story created');
    }

    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Database initialization error:', error);
  } finally {
    client.release();
  }
}

// Middleware
app.use(cors());
app.use(express.json());
app.use(session({
  secret: process.env.SESSION_SECRET || 'your-secret-key-change-in-production',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false, maxAge: 24 * 60 * 60 * 1000 }
}));

// Auth middleware
const authMiddleware = async (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  // In production, verify JWT token properly
  next();
};

// Admin routes
app.post('/api/admin/login', async (req, res) => {
  const { username, password } = req.body;
  
  try {
    const result = await pool.query('SELECT * FROM admins WHERE username = $1', [username]);
    if (result.rows.length === 0) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const admin = result.rows[0];
    const validPassword = await bcrypt.compare(password, admin.password_hash);
    
    if (!validPassword) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    await pool.query('UPDATE admins SET last_login = CURRENT_TIMESTAMP WHERE id = $1', [admin.id]);
    
    res.json({ 
      token: 'admin-token-' + admin.id,
      message: 'Login successful'
    });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/admin/change-password', authMiddleware, async (req, res) => {
  const { oldPassword, newPassword } = req.body;
  
  try {
    const result = await pool.query('SELECT * FROM admins WHERE username = $1', ['ArunKumar']);
    const admin = result.rows[0];
    
    const validPassword = await bcrypt.compare(oldPassword, admin.password_hash);
    if (!validPassword) {
      return res.status(400).json({ error: 'Old password is incorrect.' });
    }

    const hashedPassword = await bcrypt.hash(newPassword, 10);
    await pool.query('UPDATE admins SET password_hash = $1 WHERE id = $2', [hashedPassword, admin.id]);
    
    res.json({ message: 'Password changed successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Story routes
app.get('/api/stories', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT s.*, COUNT(c.id) as comments_count 
      FROM stories s 
      LEFT JOIN comments c ON s.id = c.story_id 
      WHERE s.publish_date <= CURRENT_DATE
      GROUP BY s.id 
      ORDER BY s.publish_date DESC
    `);
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/api/stories/:id', async (req, res) => {
  try {
    const { id } = req.params;
    await pool.query('UPDATE stories SET views = views + 1 WHERE id = $1', [id]);
    const result = await pool.query('SELECT * FROM stories WHERE id = $1', [id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Story not found' });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/stories', authMiddleware, async (req, res) => {
  const { title, content, category, tags, publishDate } = req.body;
  
  try {
    const result = await pool.query(
      'INSERT INTO stories (title, content, category, tags, publish_date) VALUES ($1, $2, $3, $4, $5) RETURNING *',
      [title, content, category, tags, publishDate]
    );
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

app.put('/api/stories/:id', authMiddleware, async (req, res) => {
  const { id } = req.params;
  const { title, content, category, tags, publishDate } = req.body;
  
  try {
    const result = await pool.query(
      'UPDATE stories SET title = $1, content = $2, category = $3, tags = $4, publish_date = $5, updated_at = CURRENT_TIMESTAMP WHERE id = $6 RETURNING *',
      [title, content, category, tags, publishDate, id]
    );
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

app.delete('/api/stories/:id', authMiddleware, async (req, res) => {
  const { id } = req.params;
  
  try {
    await pool.query('DELETE FROM stories WHERE id = $1', [id]);
    res.json({ message: 'Story deleted' });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Comment routes
app.get('/api/comments', async (req, res) => {
  const { storyId } = req.query;
  
  try {
    let query = `
      SELECT c.*, s.title as story_title 
      FROM comments c 
      LEFT JOIN stories s ON c.story_id = s.id
    `;
    const params = [];
    
    if (storyId) {
      query += ' WHERE c.story_id = $1';
      params.push(storyId);
    }
    
    query += ' ORDER BY c.created_at DESC';
    
    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/comments', async (req, res) => {
  const { storyId, visitorName, text, rating } = req.body;
  
  try {
    // Update or insert visitor session
    await pool.query(
      'INSERT INTO visitor_sessions (name, last_active) VALUES ($1, CURRENT_TIMESTAMP) ON CONFLICT DO NOTHING',
      [visitorName]
    );
    
    const result = await pool.query(
      'INSERT INTO comments (story_id, visitor_name, text, rating) VALUES ($1, $2, $3, $4) RETURNING *',
      [storyId, visitorName, text, rating]
    );
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

app.delete('/api/comments/:id', authMiddleware, async (req, res) => {
  const { id } = req.params;
  
  try {
    await pool.query('DELETE FROM comments WHERE id = $1', [id]);
    res.json({ message: 'Comment deleted' });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// User routes
app.get('/api/users', authMiddleware, async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        vs.name,
        vs.last_active,
        COUNT(c.id) as comment_count
      FROM visitor_sessions vs
      LEFT JOIN comments c ON vs.name = c.visitor_name
      GROUP BY vs.name, vs.last_active
      ORDER BY vs.last_active DESC
    `);
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Analytics routes
app.get('/api/analytics', authMiddleware, async (req, res) => {
  try {
    const viewsResult = await pool.query('SELECT SUM(views) as total FROM stories');
    const commentsResult = await pool.query('SELECT COUNT(*) as total FROM comments');
    const visitorsResult = await pool.query('SELECT COUNT(DISTINCT name) as total FROM visitor_sessions');
    
    res.json({
      totalViews: parseInt(viewsResult.rows[0].total) || 0,
      totalComments: parseInt(commentsResult.rows[0].total) || 0,
      totalVisitors: parseInt(visitorsResult.rows[0].total) || 0
    });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Initialize database and start server
initDatabase().then(() => {
  app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
});
