import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import Header from './components/Header';
import Footer from './components/Footer';
import HomePage from './pages/HomePage';
import StoryPage from './pages/StoryPage';
import AdminLogin from './pages/AdminLogin';
import AdminDashboard from './pages/AdminDashboard';
import CreateStory from './pages/CreateStory';
import EditStory from './pages/EditStory';
import UsersComments from './pages/UsersComments';
import Settings from './pages/Settings';
import PrivacyPolicy from './pages/PrivacyPolicy';
import NameEntryModal from './components/NameEntryModal';

function App() {
  const [visitorName, setVisitorName] = useState('');
  const [showNameModal, setShowNameModal] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    const storedName = localStorage.getItem('visitorName');
    if (storedName) {
      setVisitorName(storedName);
    }

    const adminToken = localStorage.getItem('adminToken');
    if (adminToken) {
      setIsAdmin(true);
    }

    const theme = localStorage.getItem('theme');
    if (theme === 'dark') {
      setDarkMode(true);
      document.documentElement.classList.add('dark');
    }
  }, []);

  const handleNameSubmit = (name) => {
    setVisitorName(name);
    localStorage.setItem('visitorName', name);
    setShowNameModal(false);
  };

  const handleNameChange = (newName) => {
    setVisitorName(newName);
    localStorage.setItem('visitorName', newName);
  };

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
    if (!darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('adminToken');
    setIsAdmin(false);
  };

  return (
    <Router>
      <div className="min-h-screen bg-gradient-to-br from-secondary-50 to-primary-50 dark:from-secondary-900 dark:to-secondary-800 transition-colors duration-300">
        <Header 
          visitorName={visitorName} 
          onNameChange={handleNameChange}
          darkMode={darkMode}
          toggleDarkMode={toggleDarkMode}
          isAdmin={isAdmin}
          onLogout={handleLogout}
        />
        
        <main className="container mx-auto px-4 py-8 min-h-[calc(100vh-200px)]">
          <AnimatePresence mode="wait">
            <Routes>
              <Route path="/" element={<HomePage visitorName={visitorName} setShowNameModal={setShowNameModal} />} />
              <Route path="/story/:id" element={<StoryPage visitorName={visitorName} setShowNameModal={setShowNameModal} />} />
              <Route path="/admin/login" element={<AdminLogin setIsAdmin={setIsAdmin} />} />
              <Route path="/admin/dashboard" element={isAdmin ? <AdminDashboard /> : <Navigate to="/admin/login" />} />
              <Route path="/admin/create-story" element={isAdmin ? <CreateStory /> : <Navigate to="/admin/login" />} />
              <Route path="/admin/edit-story/:id" element={isAdmin ? <EditStory /> : <Navigate to="/admin/login" />} />
              <Route path="/admin/users-comments" element={isAdmin ? <UsersComments /> : <Navigate to="/admin/login" />} />
              <Route path="/admin/settings" element={isAdmin ? <Settings /> : <Navigate to="/admin/login" />} />
              <Route path="/privacy-policy" element={<PrivacyPolicy />} />
            </Routes>
          </AnimatePresence>
        </main>

        <Footer />

        <AnimatePresence>
          {showNameModal && !visitorName && (
            <NameEntryModal onSubmit={handleNameSubmit} />
          )}
        </AnimatePresence>
      </div>
    </Router>
  );
}

export default App;
