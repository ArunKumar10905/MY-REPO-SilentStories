import React from 'react';
import { Link } from 'react-router-dom';
import { Heart } from 'lucide-react';

function Footer() {
  return (
    <footer className="bg-white dark:bg-secondary-800 border-t border-secondary-200 dark:border-secondary-700 mt-16 transition-colors duration-300">
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          <div className="flex items-center space-x-2 text-secondary-600 dark:text-secondary-300">
            <span>Made with</span>
            <Heart className="w-4 h-4 text-accent-500 fill-current" />
            <span>for storytellers</span>
          </div>

          <div className="flex space-x-6">
            <Link 
              to="/privacy-policy" 
              className="text-secondary-600 dark:text-secondary-300 hover:text-primary-500 dark:hover:text-primary-400 transition-colors"
            >
              Privacy Policy
            </Link>
            <Link 
              to="/admin/login" 
              className="text-secondary-600 dark:text-secondary-300 hover:text-primary-500 dark:hover:text-primary-400 transition-colors"
            >
              Admin
            </Link>
          </div>
        </div>

        <div className="text-center mt-6 text-sm text-secondary-500 dark:text-secondary-400">
          © {new Date().getFullYear()} Monthly Stories. All rights reserved.
        </div>
      </div>
    </footer>
  );
}

export default Footer;
