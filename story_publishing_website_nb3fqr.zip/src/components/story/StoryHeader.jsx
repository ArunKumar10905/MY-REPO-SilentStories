import React from 'react';
import { Calendar, Eye, MessageCircle } from 'lucide-react';
import { format } from 'date-fns';

function StoryHeader({ story, commentsCount }) {
  return (
    <div className="mb-6">
      <h1 className="text-4xl font-bold text-secondary-800 dark:text-white mb-4">
        {story.title}
      </h1>
      
      <div className="flex flex-wrap items-center gap-4 text-sm text-secondary-600 dark:text-secondary-300 mb-4">
        <div className="flex items-center space-x-1">
          <Calendar className="w-4 h-4" />
          <span>{format(new Date(story.publish_date), 'MMMM dd, yyyy')}</span>
        </div>
        <div className="flex items-center space-x-1">
          <Eye className="w-4 h-4" />
          <span>{story.views} views</span>
        </div>
        <div className="flex items-center space-x-1">
          <MessageCircle className="w-4 h-4" />
          <span>{commentsCount} comments</span>
        </div>
      </div>
    </div>
  );
}

export default StoryHeader;
