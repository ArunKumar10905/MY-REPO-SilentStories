import React from 'react';

function StoryContent({ content, fontSize }) {
  const fontSizes = {
    small: 'text-base',
    medium: 'text-lg',
    large: 'text-xl'
  };

  return (
    <div
      className={`story-content ${fontSizes[fontSize]}`}
      dangerouslySetInnerHTML={{ __html: content }}
    />
  );
}

export default StoryContent;
