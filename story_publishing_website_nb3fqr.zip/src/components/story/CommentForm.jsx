import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Star } from 'lucide-react';

function CommentForm({ storyId, visitorName, onCommentSubmit }) {
  const [rating, setRating] = useState(0);
  const [commentText, setCommentText] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!commentText.trim() && rating === 0) return;

    setSubmitting(true);
    try {
      const response = await fetch('/api/comments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          storyId,
          visitorName,
          text: commentText.trim(),
          rating: rating || null
        })
      });

      if (response.ok) {
        setCommentText('');
        setRating(0);
        onCommentSubmit();
      }
    } catch (error) {
      console.error('Error submitting comment:', error);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="mb-8">
      <div className="mb-4">
        <label className="block text-sm font-medium text-secondary-700 dark:text-secondary-300 mb-2">
          Rate this story
        </label>
        <div className="flex space-x-2">
          {[1, 2, 3, 4, 5].map((star) => (
            <motion.button
              key={star}
              type="button"
              whileHover={{ scale: 1.2 }}
              whileTap={{ scale: 0.9 }}
              onClick={() => setRating(star)}
              className="focus:outline-none"
            >
              <Star
                className={`w-8 h-8 ${
                  star <= rating
                    ? 'text-yellow-500 fill-current'
                    : 'text-secondary-300 dark:text-secondary-600'
                }`}
              />
            </motion.button>
          ))}
        </div>
      </div>

      <textarea
        value={commentText}
        onChange={(e) => setCommentText(e.target.value)}
        placeholder="Share your thoughts..."
        className="input-field min-h-[100px] mb-4"
      />

      <motion.button
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        type="submit"
        disabled={submitting}
        className="btn-primary"
      >
        {submitting ? 'Posting...' : 'Post comment'}
      </motion.button>
    </form>
  );
}

export default CommentForm;
