import React from 'react';
import { motion } from 'framer-motion';
import { Star } from 'lucide-react';
import { format } from 'date-fns';

function CommentsList({ comments }) {
  return (
    <div className="space-y-4">
      {comments.map((comment, index) => (
        <motion.div
          key={comment.id}
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: index * 0.1 }}
          className="border-b border-secondary-200 dark:border-secondary-700 pb-4 last:border-0"
        >
          <div className="flex items-start justify-between mb-2">
            <div>
              <p className="font-medium text-secondary-800 dark:text-white">
                {comment.visitor_name}
              </p>
              <p className="text-sm text-secondary-500 dark:text-secondary-400">
                {format(new Date(comment.created_at), 'MMM dd, yyyy HH:mm')}
              </p>
            </div>
            {comment.rating && (
              <div className="flex">
                {[...Array(comment.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 text-yellow-500 fill-current" />
                ))}
              </div>
            )}
          </div>
          {comment.text && (
            <p className="text-secondary-700 dark:text-secondary-300">
              {comment.text}
            </p>
          )}
        </motion.div>
      ))}

      {comments.length === 0 && (
        <p className="text-center text-secondary-500 dark:text-secondary-400 py-8">
          No comments yet. Be the first to share your thoughts!
        </p>
      )}
    </div>
  );
}

export default CommentsList;
