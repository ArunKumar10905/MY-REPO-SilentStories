import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Plus, Eye, MessageCircle, TrendingUp } from 'lucide-react';
import StatsCard from '../components/admin/StatsCard';
import StoriesTable from '../components/admin/StoriesTable';

function AdminDashboard() {
  const [stories, setStories] = useState([]);
  const [stats, setStats] = useState({ totalViews: 0, totalComments: 0, totalVisitors: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchStories();
    fetchStats();
  }, []);

  const fetchStories = async () => {
    try {
      const response = await fetch('/api/stories');
      const data = await response.json();
      setStories(data);
    } catch (error) {
      console.error('Error fetching stories:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      const response = await fetch('/api/analytics', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('adminToken')}`
        }
      });
      const data = await response.json();
      setStats(data);
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  const handleDelete = async (id) => {
    if (!confirm('Are you sure you want to delete this story?')) return;

    try {
      const response = await fetch(`/api/stories/${id}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('adminToken')}`
        }
      });

      if (response.ok) {
        fetchStories();
      }
    } catch (error) {
      console.error('Error deleting story:', error);
    }
  };

  return (
    <div className="max-w-7xl mx-auto">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-4xl font-bold text-secondary-800 dark:text-white">
          Dashboard
        </h1>
        <Link to="/admin/create-story">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="btn-primary flex items-center space-x-2"
          >
            <Plus className="w-5 h-5" />
            <span>Create Story</span>
          </motion.button>
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <StatsCard
          title="Total Views"
          value={stats.totalViews}
          icon={Eye}
          delay={0}
        />
        <StatsCard
          title="Total Comments"
          value={stats.totalComments}
          icon={MessageCircle}
          delay={0.1}
        />
        <StatsCard
          title="Total Visitors"
          value={stats.totalVisitors}
          icon={TrendingUp}
          delay={0.2}
        />
      </div>

      <div className="card p-6">
        <h2 className="text-2xl font-bold text-secondary-800 dark:text-white mb-6">
          All Stories
        </h2>

        {loading ? (
          <div className="flex justify-center py-12">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
              className="w-12 h-12 border-4 border-primary-500 border-t-transparent rounded-full"
            />
          </div>
        ) : (
          <StoriesTable stories={stories} onDelete={handleDelete} />
        )}
      </div>
    </div>
  );
}

export default AdminDashboard;
