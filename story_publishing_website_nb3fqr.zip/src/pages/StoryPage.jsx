import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import ReadingProgress from '../components/story/ReadingProgress';
import StoryHeader from '../components/story/StoryHeader';
import ReadingControls from '../components/story/ReadingControls';
import StoryContent from '../components/story/StoryContent';
import CommentForm from '../components/story/CommentForm';
import CommentsList from '../components/story/CommentsList';

function StoryPage({ visitorName, setShowNameModal }) {
  const { id } = useParams();
  const navigate = useNavigate();
  const [story, setStory] = useState(null);
  const [comments, setComments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [fontSize, setFontSize] = useState('medium');
  const [bookmarked, setBookmarked] = useState(false);

  useEffect(() => {
    if (!visitorName) {
      setShowNameModal(true);
      navigate('/');
      return;
    }
    fetchStory();
    fetchComments();
    checkBookmark();
  }, [id, visitorName]);

  const fetchStory = async () => {
    try {
      const response = await fetch(`/api/stories/${id}`);
      const data = await response.json();
      setStory(data);
    } catch (error) {
      console.error('Error fetching story:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchComments = async () => {
    try {
      const response = await fetch(`/api/comments?storyId=${id}`);
      const data = await response.json();
      setComments(data);
    } catch (error) {
      console.error('Error fetching comments:', error);
    }
  };

  const checkBookmark = () => {
    const bookmarks = JSON.parse(localStorage.getItem('bookmarks') || '[]');
    setBookmarked(bookmarks.includes(id));
  };

  const handleBookmark = () => {
    const bookmarks = JSON.parse(localStorage.getItem('bookmarks') || '[]');
    if (bookmarked) {
      const updated = bookmarks.filter(b => b !== id);
      localStorage.setItem('bookmarks', JSON.stringify(updated));
      setBookmarked(false);
    } else {
      bookmarks.push(id);
      localStorage.setItem('bookmarks', JSON.stringify(bookmarks));
      setBookmarked(true);
    }
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: story.title,
        url: window.location.href
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      alert('Link copied to clipboard!');
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="w-12 h-12 border-4 border-primary-500 border-t-transparent rounded-full"
        />
      </div>
    );
  }

  if (!story) {
    return (
      <div className="text-center py-16">
        <p className="text-xl text-secondary-600 dark:text-secondary-300">
          Story not found
        </p>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <ReadingProgress />

      <motion.article
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="card p-8 mb-8"
      >
        <StoryHeader story={story} commentsCount={comments.length} />
        <ReadingControls
          fontSize={fontSize}
          setFontSize={setFontSize}
          bookmarked={bookmarked}
          onBookmark={handleBookmark}
          onShare={handleShare}
        />
        <StoryContent content={story.content} fontSize={fontSize} />
      </motion.article>

      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="card p-8"
      >
        <h2 className="text-2xl font-bold text-secondary-800 dark:text-white mb-6">
          Comments & Reviews
        </h2>

        <CommentForm
          storyId={id}
          visitorName={visitorName}
          onCommentSubmit={fetchComments}
        />

        <CommentsList comments={comments} />
      </motion.section>
    </div>
  );
}

export default StoryPage;
