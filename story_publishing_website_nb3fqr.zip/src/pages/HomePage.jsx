import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import StoryCard from '../components/StoryCard';
import { TrendingUp, Clock } from 'lucide-react';

function HomePage({ visitorName, setShowNameModal }) {
  const [stories, setStories] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchStories();
  }, []);

  const fetchStories = async () => {
    try {
      const response = await fetch('/api/stories');
      const data = await response.json();
      setStories(data);
    } catch (error) {
      console.error('Error fetching stories:', error);
    } finally {
      setLoading(false);
    }
  };

  const featuredStories = stories.slice(0, 3);
  const recentStories = stories.slice(3);

  return (
    <div className="max-w-7xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-12"
      >
        <h1 className="text-5xl font-bold text-secondary-800 dark:text-white mb-4">
          Welcome to Monthly Stories
        </h1>
        <p className="text-xl text-secondary-600 dark:text-secondary-300">
          Discover captivating tales published monthly
        </p>
      </motion.div>

      {loading ? (
        <div className="flex justify-center items-center h-64">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
            className="w-12 h-12 border-4 border-primary-500 border-t-transparent rounded-full"
          />
        </div>
      ) : (
        <>
          {featuredStories.length > 0 && (
            <section className="mb-12">
              <div className="flex items-center space-x-2 mb-6">
                <TrendingUp className="w-6 h-6 text-accent-500" />
                <h2 className="text-3xl font-bold text-secondary-800 dark:text-white">
                  Featured Stories
                </h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {featuredStories.map((story, index) => (
                  <StoryCard key={story.id} story={story} index={index} />
                ))}
              </div>
            </section>
          )}

          {recentStories.length > 0 && (
            <section>
              <div className="flex items-center space-x-2 mb-6">
                <Clock className="w-6 h-6 text-primary-500" />
                <h2 className="text-3xl font-bold text-secondary-800 dark:text-white">
                  Recent Stories
                </h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {recentStories.map((story, index) => (
                  <StoryCard key={story.id} story={story} index={index + 3} />
                ))}
              </div>
            </section>
          )}

          {stories.length === 0 && (
            <div className="text-center py-16">
              <p className="text-xl text-secondary-600 dark:text-secondary-300">
                No stories published yet. Check back soon!
              </p>
            </div>
          )}
        </>
      )}
    </div>
  );
}

export default HomePage;
