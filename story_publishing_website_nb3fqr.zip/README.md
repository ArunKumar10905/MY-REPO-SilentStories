# Monthly Stories Website

A beautiful, minimal story publishing platform with admin controls and visitor engagement features.

## Features

- **Admin Dashboard**: Create, edit, and manage stories
- **Visitor Experience**: Read stories with customizable reading controls
- **Comments & Ratings**: Engage with stories through comments and star ratings
- **Analytics**: Track views, comments, and visitor engagement
- **Responsive Design**: Works seamlessly on desktop and mobile
- **Dark Mode**: Toggle between light and dark themes

## Tech Stack

- **Frontend**: React, TailwindCSS, Framer Motion
- **Backend**: Node.js, Express
- **Database**: PostgreSQL
- **Authentication**: bcrypt password hashing

## Setup Instructions

### Prerequisites

- Node.js (v16 or higher)
- PostgreSQL (v12 or higher)

### Installation

1. Install dependencies:
```bash
npm install
```

2. Set up PostgreSQL database:
```bash
createdb story_website
```

3. Create `.env` file:
```bash
cp .env.example .env
```

Edit `.env` with your database credentials.

4. Start the backend server:
```bash
npm run server
```

5. In a new terminal, start the frontend:
```bash
npm run dev
```

## Default Admin Credentials

- **Username**: ArunKumar
- **Password**: 10092005

⚠️ **Important**: Change the default password after first login!

## Usage

### For Admin

1. Navigate to `/admin/login`
2. Login with default credentials
3. Access Dashboard to manage stories
4. View Users & Comments section
5. Change password in Settings

### For Visitors

1. Enter your name when prompted
2. Browse and read stories
3. Leave comments and ratings
4. Customize reading experience (font size, theme)

## API Endpoints

### Admin
- `POST /api/admin/login` - Admin login
- `POST /api/admin/change-password` - Change admin password

### Stories
- `GET /api/stories` - List all stories
- `GET /api/stories/:id` - Get single story
- `POST /api/stories` - Create story (admin)
- `PUT /api/stories/:id` - Update story (admin)
- `DELETE /api/stories/:id` - Delete story (admin)

### Comments
- `GET /api/comments?storyId=:id` - Get comments
- `POST /api/comments` - Post comment
- `DELETE /api/comments/:id` - Delete comment (admin)

### Analytics
- `GET /api/analytics` - Get site statistics (admin)
- `GET /api/users` - Get visitor list (admin)

## Security Features

- Password hashing with bcrypt
- Session management
- Admin-only routes protection
- Rate limiting on comments
- HTTPS ready

## License

MIT License - feel free to use for your own projects!
